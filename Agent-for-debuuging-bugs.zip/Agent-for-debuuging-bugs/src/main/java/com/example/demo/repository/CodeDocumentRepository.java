package com.example.demo.repository;

import com.example.demo.entity.CodeDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CodeDocumentRepository extends JpaRepository<CodeDocument,Long> {
    Optional<CodeDocument> findByRepositoryAndBranchAndPath(String repository,String branch,String path);

    List<CodeDocument> findByRepositoryAndBranch(String repository,String branch);

    List<CodeDocument> findByPathContainingIgnoreCaseOrContentContainingIgnoreCase(String path,String content);
}
