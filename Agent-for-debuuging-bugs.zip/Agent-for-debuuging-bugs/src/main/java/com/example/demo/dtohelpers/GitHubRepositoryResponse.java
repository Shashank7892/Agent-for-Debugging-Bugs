package com.example.demo.dtohelpers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GitHubRepositoryResponse {

    private Long id;

    private String name;

    private String full_name;

    private String default_branch;

    private String html_url;

}
