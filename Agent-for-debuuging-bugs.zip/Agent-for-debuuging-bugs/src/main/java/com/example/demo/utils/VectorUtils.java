package com.example.demo.utils;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service
public class VectorUtils {

    public String toVectorString(float[] embedding){
        StringBuilder builder=new StringBuilder("[");
        for(int i=0;i<embedding.length;i++){
            if(i>0){
                builder.append(",");
            }
            builder.append(embedding[i]);
        }
        builder.append("]");

        return builder.toString();
    }
}
