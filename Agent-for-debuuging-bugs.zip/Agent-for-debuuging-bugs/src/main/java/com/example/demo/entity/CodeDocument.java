package com.example.demo.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "code_documents", indexes={
        @Index(name = "idx_repo_path", columnList = "repository,path")
})
public class CodeDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String repository;

    private String branch;

    @Column(columnDefinition = "TEXT")
    private String path;

    private String language;

    @Column(columnDefinition = "TEXT")
    private String content;

    private  String fileSha;
}
