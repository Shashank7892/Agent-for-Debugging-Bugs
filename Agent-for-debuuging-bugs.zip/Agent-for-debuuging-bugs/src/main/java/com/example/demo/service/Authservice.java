package com.example.demo.service;

import com.example.demo.dtohelpers.LoginDTO;
import com.example.demo.dtohelpers.UserLoginDTO;
import com.example.demo.dtohelpers.UserResgisterDTO;
import com.example.demo.entity.UserDetailss;
import com.example.demo.jwt.JwtService;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class Authservice {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;


    public UserLoginDTO registerUser(UserResgisterDTO userResgisterDTO) {
        UserDetailss user=userRepository.findByEmail(userResgisterDTO.getEmail()).orElse(null);
        if(user!=null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User Already Exists");
        }
        try {
                UserDetailss newuser = new UserDetailss();
                newuser.setEmail(userResgisterDTO.getEmail());
                newuser.setName(userResgisterDTO.getName());
                newuser.setPassword(passwordEncoder.encode(userResgisterDTO.getPassword()));

                userRepository.save(newuser);
                String genratetoken=tokengeneration(newuser.getEmail(),newuser.getName());
                UserLoginDTO login = UserLoginDTO.builder()
                        .token(genratetoken)
                        .username(newuser.getName())
                        .build();

                return login;
            }
        catch (Exception ex){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Registration Failed");
        }
    }

    public UserLoginDTO login(LoginDTO loginDTO) {

        try{
            System.out.println("before authentication");
            Authentication authentication= authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginDTO.getEmail(),loginDTO.getPassword()));
            System.out.println(authentication.getPrincipal());
            User user=(User) authentication.getPrincipal();
            System.out.println("This is the user name email "+user.getUsername());
            UserDetailss userdeatails=userRepository.findByEmail(user.getUsername()).orElseThrow(()-> new UsernameNotFoundException("Username not found"));

            System.out.println("Came here");
            String genratetoken=tokengeneration(user.getUsername(), userdeatails.getName());

       UserLoginDTO login=UserLoginDTO.builder()
               .token(genratetoken)
               .username(userdeatails.getName())
               .build();
       System.out.println("After authentication");
       return login;
        }
        catch (AuthenticationException ex){
            System.out.println("Exception catched here");
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid Username or password");
        }
    }


    private String tokengeneration(String username,String name){
        String token=jwtService.generateToken(username,name);
        return token;
    }
}
