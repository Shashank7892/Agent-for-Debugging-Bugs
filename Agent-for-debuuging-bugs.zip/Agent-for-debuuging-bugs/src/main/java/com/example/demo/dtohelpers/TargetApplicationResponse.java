package com.example.demo.dtohelpers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TargetApplicationResponse {

    private String name;

    private String github;

    private String branch;

    private String status;

    private String lastIndexed;
}
