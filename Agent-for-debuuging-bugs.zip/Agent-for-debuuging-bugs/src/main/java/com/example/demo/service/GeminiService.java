package com.example.demo.service;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class GeminiService {


    private ChatClient chatClient;

    @Autowired
    private ChatClient.Builder chatClientBuilder;
    
//    public GeminiService(ChatClient.Builder chatClientBuilder){
//        this.chatClient=chatClientBuilder.build();
//    }
    public String generateAnswer(String prompt){

        chatClient=chatClientBuilder.build();

        return chatClient
                .prompt()
                .user(prompt)
                .call()
                .content();
    }
}
