package com.example.demo.service;

import com.example.demo.entity.CodeChunk;
import com.example.demo.entity.CodeDocument;
import com.example.demo.repository.CodeChunkRepository;
import com.github.javaparser.Range;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.MethodDeclaration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CodeChunkingService {

    @Autowired
    private CodeChunkRepository codeChunkRepository;

    @Autowired
    private EmbeddingServices embeddingServices;

    public void chunkDocument(CodeDocument document){
        String language=document.getLanguage();
        String content=document.getContent();

        if(content==null || content.isBlank()){
            return;
        }

        //Remove old chunks when document changes
        codeChunkRepository.deleteByDocumentId(document.getId());
        if("java".equalsIgnoreCase(language)){
            chunkByJava(document);
        }
        else{
            chunkByLines(document);
        }

    }

    private void chunkByJava(CodeDocument document){
        CompilationUnit compilationUnit= StaticJavaParser.parse(document.getContent());

        List<MethodDeclaration> methods=compilationUnit.findAll(MethodDeclaration.class);

        List<CodeChunk> chunks=new ArrayList<>();
        int chunkindex=0;
        for(MethodDeclaration method:methods){
            CodeChunk chunk=new CodeChunk();
            chunk.setDocument(document);
            chunk.setChunkIndex(chunkindex);
            chunk.setContent(method.toString());
            // Generate embedding
            float[] embedding=embeddingServices.generateEmbedding(chunk.getContent());
            // Store embedding in CodeChunk
            chunk.setEmbedding(embedding);
            if(method.getRange().isPresent()){
                Range range=method.getRange().get();
                chunk.setStartLine(range.begin.line);
                chunk.setEndLine(range.end.line);
            }
            chunks.add(chunk);
            chunkindex++;
        }
        codeChunkRepository.saveAll(chunks);
    }


    private void chunkByLines(CodeDocument document) {

        String content = document.getContent();

        String[] lines = content.split("\\R", -1);

        int chunkSize = 30;

        int chunkIndex = 0;

        for (int start = 0; start < lines.length; start += chunkSize) {

            int end = Math.min(
                    start + chunkSize,
                    lines.length
            );

            StringBuilder chunkContent = new StringBuilder();

            for (int i = start; i < end; i++) {

                chunkContent
                        .append(lines[i])
                        .append("\n");
            }

            CodeChunk chunk = new CodeChunk();

            chunk.setDocument(document);
            chunk.setChunkIndex(chunkIndex++);

            chunk.setStartLine(start + 1);
            chunk.setEndLine(end);

            chunk.setContent(chunkContent.toString());
            float[] embedding= embeddingServices.generateEmbedding(chunk.getContent());
            System.out.println("Embedding dimensions: " + embedding.length);
            chunk.setEmbedding(embedding);

            codeChunkRepository.save(chunk);
        }
    }
}
