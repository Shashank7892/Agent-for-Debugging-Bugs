package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class RagPromptService {

    public String buildPrompt(String query,String context){
        return """
                You are an expert Java software debugging assistant.

                Your job is to analyze the user's question using the provided
                source code context.

                User Question:
                %s

                Relevant Source Code:
                %s

                Instructions:
                1. Use the provided source code as the primary source of evidence.
                2. Identify the most likely root cause of the problem.
                3. Explain why the problem is happening.
                4. Mention the relevant file and line numbers when available.
                5. Suggest a concrete fix.
                6. Do not invent code or facts that are not supported by the provided context.
                7. If the provided code is insufficient to determine the root cause,
                   clearly say what additional code or information is needed.

                Provide a clear and technically accurate answer.
                """.formatted(query, context);


    }
}
