package com.example.demo.service;

import com.example.demo.entity.CodeChunk;
import com.example.demo.repository.CodeChunkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.utils.VectorUtils;

import java.util.List;

@Service
public class SemanticSearchService {

    @Autowired
    private EmbeddingServices embeddingServices;

    @Autowired
    private CodeChunkRepository codeChunkRepository;

    @Autowired
    private VectorUtils vectorUtils;

    public List<CodeChunk> search(String query,int limit){

        // 1. Convert user query into embedding
        float[] queryembedding=embeddingServices.generateEmbedding(query);

        // 2. Convert float[] into PostgreSQL vector format
        String vector=vectorUtils.toVectorString(queryembedding);

        System.out.println(limit+5);
        // 3. Search PostgreSQL using vector similarity
        return codeChunkRepository.sematicsearch(vector,limit);
    }

}
