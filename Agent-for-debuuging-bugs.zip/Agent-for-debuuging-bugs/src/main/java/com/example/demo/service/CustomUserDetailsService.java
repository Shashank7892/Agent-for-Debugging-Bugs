package com.example.demo.service;

import com.example.demo.entity.UserDetailss;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        UserDetailss user=userRepository.findByEmail(email).orElseThrow(()-> new UsernameNotFoundException("User Not Found"));
        System.out.println("i am here"+ user.getEmail());
        User u=new User(user.getEmail(), user.getPassword(), Collections.emptyList());
        System.out.println(u.getUsername());
        return new User(user.getEmail(), user.getPassword(),Collections.emptyList());
    }
}
