package com.example.demo.controller;

import com.example.demo.entity.CodeChunk;
import com.example.demo.service.HybridSearchService;
import com.example.demo.service.SemanticSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SemanticSearchController {

    @Autowired
    private SemanticSearchService semanticSearchService;

    @Autowired
    private HybridSearchService hybridSearchService;

    @GetMapping("/semantic")
    public List<CodeChunk> semanticSearch(@RequestParam String query,@RequestParam(defaultValue = "5") int limit){
        return semanticSearchService.search(query,limit);
    }

    @GetMapping("/hybrid")
    public List<CodeChunk> hybridSearch(
            @RequestParam String query) {

        return hybridSearchService.search(query);
    }
}
