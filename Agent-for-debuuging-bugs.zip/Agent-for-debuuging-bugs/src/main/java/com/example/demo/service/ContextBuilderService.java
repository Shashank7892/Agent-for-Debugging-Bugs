package com.example.demo.service;

import com.example.demo.entity.CodeChunk;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContextBuilderService {

    public String buildContext(List<CodeChunk> chunks){

        StringBuilder context=new StringBuilder();
        for(CodeChunk chunk:chunks){
            context.append("---code Chunk----\n");
            context.append("File: ")
                    .append(chunk.getDocument().getPath())
                    .append("\n");
            context.append("Lines: ")
                    .append(chunk.getStartLine())
                    .append("-")
                    .append(chunk.getEndLine())
                    .append("\n\n");
            context.append(chunk.getContent())
                    .append("\n\n");
        }
        System.out.println(context.toString());
        return context.toString();
    }
}
