package com.example.demo.jwt;

import com.example.demo.config.GitHubConfig;
import io.jsonwebtoken.Jwts;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.pkcs.RSAPrivateKey;
import org.bouncycastle.jce.provider.PEMUtil;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateCrtKeySpec;
import java.time.Instant;
import java.util.Base64;
import java.util.Date;

@Service
public class GitHubJwtService {

    @Autowired
    private GitHubConfig config;

    public String generateGitHubAppJwt() throws Exception{
        PrivateKey privateKey=loadPrivateKey();

        Instant now=Instant.now();

        return Jwts.builder()
                .issuer(String.valueOf(config.getAppId()))
                .issuedAt(Date.from(now.minusSeconds(60)))
                .expiration(Date.from(now.plusSeconds(540)))
                .signWith(privateKey,Jwts.SIG.RS256)
                .compact();
    }

    private PrivateKey loadPrivateKey() throws Exception{
        String key = config.getPrivateKeyPath();

        byte[] decoded = Base64.getDecoder().decode(key);

        RSAPrivateKey rsaPrivateKey =
                RSAPrivateKey.getInstance(
                        ASN1Primitive.fromByteArray(decoded)
                );

        RSAPrivateCrtKeySpec spec =
                new RSAPrivateCrtKeySpec(
                        rsaPrivateKey.getModulus(),
                        rsaPrivateKey.getPublicExponent(),
                        rsaPrivateKey.getPrivateExponent(),
                        rsaPrivateKey.getPrime1(),
                        rsaPrivateKey.getPrime2(),
                        rsaPrivateKey.getExponent1(),
                        rsaPrivateKey.getExponent2(),
                        rsaPrivateKey.getCoefficient()
                );

        PrivateKey privateKey =
                KeyFactory.getInstance("RSA")
                        .generatePrivate(spec);

        return privateKey;
////      try(PEMParser parser=new PEMParser(new StringReader(key))){
////          Object object=parser.readObject();
////
////          System.out.println("Actually in PEMParser "+ object.toString());
////          JcaPEMKeyConverter converter=new JcaPEMKeyConverter();
////
////          if(object instanceof PEMKeyPair keyPair){
////              System.out.println("The Converted String key "+ converter.getKeyPair(keyPair).getPrivate());
////              return converter.getKeyPair(keyPair)
////                      .getPrivate();
////          }
////
////          if(object instanceof PrivateKeyInfo privateKeyInfo){
////              System.out.println("The Converted String key private Info "+ converter.getPrivateKey(privateKeyInfo));
////              return converter.getPrivateKey(privateKeyInfo);
////          }
////
////          throw new IllegalArgumentException("Unsupported GitHub private Key format");
////      }
      }
}
