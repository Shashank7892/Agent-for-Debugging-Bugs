package com.example.demo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GitHubConfig {

    @Value("${github.app.id}")
    private Long appId;

    @Value("${github.privatekey}")
    private String privateKeyPath;

    @Value("${github.target.owner}")
    private String owner;

    @Value("${github.target.repository}")
    private String repository;

    @Value("${github.target.branch}")
    private String branch;

    public Long getAppId(){
        return appId;
    }

    public String getOwner(){
        return owner;
    }

    public String getRepository(){
        return repository;
    }

    public String getBranch(){
        return branch;
    }

    public String getPrivateKeyPath(){
        return privateKeyPath;
    }
}
