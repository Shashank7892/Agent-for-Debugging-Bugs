package com.example.demo.dtohelpers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CodeSearchResultDTO {
    private String file;

    private Integer startLine;

    private Integer endLine;

    private String content;
}
