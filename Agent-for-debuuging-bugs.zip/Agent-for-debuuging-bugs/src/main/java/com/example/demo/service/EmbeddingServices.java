package com.example.demo.service;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.stereotype.Service;

@Service
public class EmbeddingServices {

    private final EmbeddingModel embeddingModel;

    public EmbeddingServices(EmbeddingModel embeddingModel){
        this.embeddingModel=embeddingModel;
    }

    public float[] generateEmbedding(String text){

        return embeddingModel.embed(text);
    }
}
