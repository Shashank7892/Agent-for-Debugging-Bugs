package com.example.demo.controller;

import com.example.demo.dtohelpers.LoginDTO;
import com.example.demo.dtohelpers.UserLoginDTO;
import com.example.demo.dtohelpers.UserResgisterDTO;
import com.example.demo.entity.UserDetailss;
import com.example.demo.service.Authservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class UserAuthController {

    @Autowired
    private Authservice authservice;

    @PostMapping("/register")
    public ResponseEntity<UserLoginDTO> register(@RequestBody UserResgisterDTO userResgisterDTO){
        UserLoginDTO Response=authservice.registerUser(userResgisterDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(Response);
    }

    @PostMapping("/login")
    public ResponseEntity<UserLoginDTO> login(@RequestBody LoginDTO loginDTO){
        System.out.println("Requesting login");
        UserLoginDTO Response=authservice.login(loginDTO);
        return ResponseEntity.status(HttpStatus.OK).body(Response);
    }

}
