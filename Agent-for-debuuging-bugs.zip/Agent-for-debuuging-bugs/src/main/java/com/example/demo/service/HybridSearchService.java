package com.example.demo.service;

import com.example.demo.entity.CodeChunk;
import com.example.demo.entity.CodeDocument;
import com.example.demo.repository.CodeChunkRepository;
import com.example.demo.utils.VectorUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class HybridSearchService {

    @Autowired
    private EmbeddingServices embeddingServices;

    @Autowired
    private CodeChunkRepository codeChunkRepository;

    @Autowired
    private SemanticSearchService semanticSearchService;


    public List<CodeChunk> search(String query) {


        //keyword Search
        List<String> keywords=extractKeywords(query);

        //for duplicate chunks
        Map<Long, CodeChunk> keywordMap = new HashMap<>();
        for(String keyword:keywords){
            List<CodeChunk> results=codeChunkRepository.keywordSearch(keyword);
            for(CodeChunk chunk:results){
                keywordMap.put(chunk.getId(),chunk);
            }
        }

        List<CodeChunk> keywordResults=new ArrayList<>(keywordMap.values());

        List<CodeChunk> semanticsearch = semanticSearchService.search(query, 10);

        Map<Long, CodeChunk> chunks = new HashMap<>();
        Map<Long, Double> scores = new HashMap<>();
        int k = 60;

        // add keyword results
        for (int i = 0; i < keywordResults.size(); i++) {
            CodeChunk chunk = keywordResults.get(i);
            chunks.put(chunk.getId(), chunk);
            double score = 1.0 / (k + i + 1);
            scores.merge(chunk.getId(), score, Double::sum);
        }


        // 5. Add semantic results
        for (int i = 0; i < semanticsearch.size(); i++) {

            CodeChunk chunk = semanticsearch.get(i);

            chunks.put(chunk.getId(), chunk);

            double score = 1.0 / (k + i + 1);

            scores.merge(
                    chunk.getId(),
                    score,
                    Double::sum
            );


        }
        return chunks.values()
                .stream()
                .sorted((a, b) -> Double.compare(scores.get(b.getId()), scores.get(a.getId())))
                .limit(5)
                .toList();
    }


    private List<String> extractKeywords(String query) {

        Set<String> stopWords = Set.of(
                "a",
                "an",
                "the",
                "is",
                "are",
                "was",
                "were",
                "why",
                "what",
                "where",
                "when",
                "how",
                "does",
                "do",
                "did",
                "to",
                "of",
                "in",
                "on",
                "for",
                "with",
                "and",
                "or"
        );

        return Arrays.stream(
                        query.toLowerCase()
                                .split("\\s+")
                )
                .map(String::trim)
                .filter(word -> !word.isEmpty())
                .filter(word -> !stopWords.contains(word))
                .toList();
    }
}
