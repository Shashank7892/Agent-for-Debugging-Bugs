package com.example.demo.dtohelpers;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InstallationTokenResponse {

    private String token;

    private String expires_at;
}
