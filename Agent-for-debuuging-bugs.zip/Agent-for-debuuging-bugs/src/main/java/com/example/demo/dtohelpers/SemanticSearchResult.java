package com.example.demo.dtohelpers;

import com.example.demo.entity.CodeChunk;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SemanticSearchResult {
    private CodeChunk chunk;
    private Double similarity;
}
