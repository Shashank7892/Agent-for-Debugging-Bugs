package com.example.demo.agents;

import com.example.demo.dtohelpers.CodeSearchResultDTO;
import com.example.demo.entity.CodeChunk;
import com.example.demo.service.HybridSearchService;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CodeSearchTool {

    @Autowired
    private HybridSearchService hybridSearchService;


    @Tool(description = "Search the repository code for relevant code related to a given query")
    public List<CodeSearchResultDTO> searchcodes(String query){

        return hybridSearchService.search(query)
                .stream()
                .limit(2)
                .map(chunk->new CodeSearchResultDTO(
                        chunk.getDocument().getPath(),
                        chunk.getStartLine(),
                        chunk.getEndLine(),
                        chunk.getContent()
                )).toList();
    }
}
