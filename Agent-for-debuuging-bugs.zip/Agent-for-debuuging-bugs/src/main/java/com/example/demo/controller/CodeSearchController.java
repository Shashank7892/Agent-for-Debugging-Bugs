package com.example.demo.controller;

import com.example.demo.entity.CodeDocument;
import com.example.demo.service.CodeSearch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class CodeSearchController {

    @Autowired
    private CodeSearch codeSearch;

    @GetMapping("/code")
    public ResponseEntity<List<CodeDocument>> searchcodes(@RequestParam String query){
        List<CodeDocument> response=codeSearch.search(query);
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
