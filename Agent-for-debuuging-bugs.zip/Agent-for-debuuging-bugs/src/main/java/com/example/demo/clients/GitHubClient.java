package com.example.demo.clients;

import com.example.demo.config.GitHubConfig;
import com.example.demo.dtohelpers.GitHubContentResponse;
import com.example.demo.dtohelpers.GitHubPathData;
import com.example.demo.dtohelpers.GitHubRepositoryResponse;
import com.example.demo.dtohelpers.GitHubTreeResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class GitHubClient {


    private final WebClient webClient;

    @Autowired
    private GitHubConfig config;

    @Autowired
    private GitHubInstallationTokenService gitHubInstallationTokenService;

    public GitHubClient(){
        this.webClient=WebClient.builder()
                .baseUrl("https://api.github.com")
                .defaultHeader(HttpHeaders.ACCEPT,"application/vnd.github+json")
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("X-GitHub-Api-Version","2022-11-28")
                .build();
    }
    public GitHubRepositoryResponse getTargetRepository(){
        String owner=config.getOwner();

        String repository=config.getRepository();
        String token=gitHubInstallationTokenService.getInstallationToken();

        return webClient.get()
                .uri("/repos/{owner}/{repo}",owner,repository)
                .headers(headers->headers.setBearerAuth(token))
                .retrieve()
                .bodyToMono(GitHubRepositoryResponse.class)
                .block();
    }

    public GitHubTreeResponse getRespositoryTree(){
        String owner=config.getOwner();
        String repository=config.getRepository();
        String branch=config.getBranch();
        String token=gitHubInstallationTokenService.getInstallationToken();
        return webClient.get()
                .uri("/repos/{owner}/{repo}/git/trees/{branch}?recursive=1",owner,repository,branch)
                .headers(headers->headers.setBearerAuth(token))
                .retrieve()
                .bodyToMono(GitHubTreeResponse.class)
                .block();
    }


    public GitHubContentResponse[] getRootContents(){
        String owner=config.getOwner();

        String repository=config.getRepository();

        String token=gitHubInstallationTokenService.getInstallationToken();
        return webClient.get()
                .uri("repos/{owner}/{repo}/contents",owner,repository)
                .headers(headers->headers.setBearerAuth(token))
                .retrieve()
                .bodyToMono(GitHubContentResponse[].class)
                .block();
    }

    public GitHubPathData getContentData(String path) {
        String owner=config.getOwner();

        String repository=config.getRepository();

        String token= gitHubInstallationTokenService.getInstallationToken();

        return webClient.get()
                .uri("repos/{owner}/{repo}/contents/{path}",owner,repository,path)
                .headers(headers->headers.setBearerAuth(token))
                .retrieve()
                .bodyToMono(GitHubPathData.class)
                .block();

    }
}
