package com.example.demo.controller;

import com.example.demo.dtohelpers.*;
import com.example.demo.service.GitHubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/target-application")
public class GitHubController {

    @Autowired
    private GitHubService gitHubService;

    @GetMapping()
    public ResponseEntity<TargetApplicationResponse> getTargetApplication(){
        System.out.println("Getting here");
        TargetApplicationResponse response=gitHubService.getTargetApplication();

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/files")
    public ResponseEntity<List<String>> getFiles(){

        List<String> response=gitHubService.getAllFiles();

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }

    @GetMapping("/rootcontents")
    public ResponseEntity<GitHubContentResponse[]> getContents(){

        GitHubContentResponse[] responses=gitHubService.getContents();

        return ResponseEntity.status(HttpStatus.OK).body(responses);
    }


    @GetMapping("/file")
    public ResponseEntity<FileData> getContentFromPath(@RequestParam String path){

        FileData response=gitHubService.readContent(path);

        return ResponseEntity.status(HttpStatus.OK).body(response);

    }
}
