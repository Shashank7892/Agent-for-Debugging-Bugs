package com.example.demo.service;

import com.example.demo.clients.GitHubClient;
import com.example.demo.config.GitHubConfig;
import com.example.demo.dtohelpers.FileData;
import com.example.demo.dtohelpers.GitHubTreeResponse;
import com.example.demo.entity.CodeDocument;
import com.example.demo.repository.CodeDocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RepositoryInjectionService {

    @Autowired
    private GitHubClient gitHubClient;

    @Autowired
    private CodeDocumentRepository codeDocumentRepository;

    @Autowired
    private GitHubService gitHubService;

    @Autowired
    private GitHubConfig gitHubConfig;

    @Autowired
    private CodeChunkingService codeChunkingService;

    public void ingestRepository(){
        GitHubTreeResponse response=gitHubClient.getRespositoryTree();

        response.getTree()
                .stream()
                .filter(item->"blob".equals(item.getType()))
                .filter(item->isRelaventFile(item.getPath()))
                .forEach(this::ingestFile);
    }

    private void ingestFile(GitHubTreeResponse.TreeItem item){
        String path=item.getPath();
        String sha= item.getSha();
        String repository= gitHubConfig.getRepository();;
        String branch= gitHubConfig.getBranch();
        System.out.println("Sha here is"+ sha);

        Optional<CodeDocument> existing=codeDocumentRepository.findByRepositoryAndBranchAndPath(repository,branch,path);
        if(existing.isPresent()){
            CodeDocument document=existing.get();
            if(sha.equals(document.getFileSha())){
                System.out.println("Skipping unchanged file: " + path);
                return;
            }
            System.out.println("Updating Changed File : "+ path);
            FileData fileData=gitHubService.readContent(path);
            document.setContent(fileData.getContent());
            document.setLanguage(detectLanguage(path));
            document.setFileSha(sha);

            CodeDocument saveddocument=codeDocumentRepository.save(document);
            codeChunkingService.chunkDocument(saveddocument);
            return;
        }
        System.out.println("Adding new file: " + path);

        FileData fileData=gitHubService.readContent(path);

        CodeDocument document=new CodeDocument();

        document.setRepository(gitHubConfig.getRepository());

        document.setBranch(gitHubConfig.getBranch());

        document.setPath(path);

        document.setLanguage(detectLanguage(path));
        document.setContent(fileData.getContent());
        document.setFileSha(item.getSha());
        CodeDocument saveddocument=codeDocumentRepository.save(document);
        codeChunkingService.chunkDocument(saveddocument);
    }

    private boolean isRelaventFile(String path) {
        String lower = path.toLowerCase();
        if (lower.startsWith(".git/")) {
            return false;
        }

        if (lower.startsWith("target/")) {
            return false;
        }

        if (lower.startsWith("node_modules/")) {
            return false;
        }
        if (lower.startsWith("build/")) {
            return false;
        }
        if (lower.startsWith("dist/")) {
            return false;
        }

        if (lower.endsWith(".class")) {
            return false;
        }

        if (lower.endsWith(".jar")) {
            return false;
        }

        if (lower.equals(".env")) {
            return false;
        }

        if (lower.contains("/secrets/")) {
            return false;
        }

        return lower.endsWith(".java")
                || lower.endsWith(".xml")
                || lower.endsWith(".yml")
                || lower.endsWith(".yaml")
                || lower.endsWith(".properties")
                || lower.endsWith(".json")
                || lower.endsWith(".sql")
                || lower.endsWith(".md")
                || lower.endsWith(".cmd");

    }

    private String detectLanguage(String path){
        String lower=path.toLowerCase();

        if(lower.endsWith(".java")){
            return "java";
        }
        if(lower.endsWith(".xml")){
            return "xml";
        }
        if(lower.endsWith(".yml")){
            return "yaml";
        }
        if(lower.endsWith(".yaml")){
            return "yaml";
        }
        if(lower.endsWith(".properties")){
            return "properties";
        }

        if(lower.endsWith(".json")){
            return "json";
        }
        if(lower.endsWith(".sql")){
            return "sql";
        }

        if(lower.endsWith(".md")){
            return "markdown";
        }
        if(lower.endsWith(".cmd")){
            return "command";
        }
        return "unknown";
    }
}
