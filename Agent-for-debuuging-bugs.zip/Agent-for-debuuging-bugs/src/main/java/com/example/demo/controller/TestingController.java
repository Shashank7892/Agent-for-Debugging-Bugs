package com.example.demo.controller;

import com.example.demo.entity.CodeChunk;
import com.example.demo.service.ContextBuilderService;
import com.example.demo.service.HybridSearchService;
import com.example.demo.service.RagPromptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/testing")
public class TestingController {

    @Autowired
    private HybridSearchService hybridSearchService;

    @Autowired
    private ContextBuilderService contextBuilderService;

    @Autowired
    private RagPromptService ragPromptService;

    @GetMapping("/context")
    public String context(@RequestParam String query){

        List<CodeChunk> chunks=hybridSearchService.search(query);

        return contextBuilderService.buildContext(chunks);
    }

    @GetMapping("/ragtesting")
    public String ragtesting(@RequestParam String query){

        List<CodeChunk> chunks=hybridSearchService.search(query);

        String context=contextBuilderService.buildContext(chunks);

        return ragPromptService.buildPrompt(query,context);

    }
}
