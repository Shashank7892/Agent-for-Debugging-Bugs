package com.example.demo.controller;

import com.example.demo.dtohelpers.QueryRequestDTO;
import com.example.demo.dtohelpers.QueryResponseDTO;
import com.example.demo.service.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/agent")
public class AgentController {

    @Autowired
    private AgentService agentService;

    @PostMapping("/ask")
    public ResponseEntity<QueryResponseDTO> askquestion(@RequestBody QueryRequestDTO query){

        QueryResponseDTO response=agentService.ask(query.getQuery());

        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
