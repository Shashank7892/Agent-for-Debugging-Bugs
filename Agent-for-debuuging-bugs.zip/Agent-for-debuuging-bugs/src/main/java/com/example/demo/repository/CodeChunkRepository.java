package com.example.demo.repository;

import com.example.demo.entity.CodeChunk;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CodeChunkRepository extends JpaRepository<CodeChunk,Long> {

    List<CodeChunk> findByDocumentIdOrderByChunkIndex(Long documentId);

    void deleteByDocumentId(Long documenId);

    @Query(value = """
SELECT * FROM code_chunks
WHERE embedding IS NOT NULL
ORDER BY embedding<=> CAST(:embedding AS vector)
LIMIT CAST(:limit AS integer)
""",nativeQuery = true)
    List<CodeChunk> sematicsearch(@Param("embedding") String embedding,
                                  @Param("limit") int limit);


    @Query(value = """
    SELECT
        id,
        document_id,
        chunk_index,
        content,
        start_line,
        end_line,
        embedding,
        1 - (embedding <=> CAST(:embedding AS vector)) AS similarity
    FROM code_chunks
    WHERE embedding IS NOT NULL
    ORDER BY embedding <=> CAST(:embedding AS vector)
    LIMIT :limit
    """,
            nativeQuery = true)
    List<Object[]> semanticSearchWithScore(
            @Param("embedding") String embedding,
            @Param("limit") int limit
    );

    @Query("""
    SELECT c
    FROM CodeChunk c
    WHERE LOWER(c.content) LIKE LOWER(CONCAT('%', :query, '%'))
       OR LOWER(c.document.path) LIKE LOWER(CONCAT('%', :query, '%'))
""")
    List<CodeChunk> keywordSearch(@Param("query") String query);
}
