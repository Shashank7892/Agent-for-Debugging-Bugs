package com.example.demo.controller;

import com.example.demo.service.RepositoryInjectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/repository")
public class RepositoryIngestionController {

    @Autowired
    private RepositoryInjectionService repositoryInjectionService;

    @PostMapping("/ingest")
    public ResponseEntity<String> ingest(){
         repositoryInjectionService.ingestRepository();
         return ResponseEntity.status(HttpStatus.OK).body("Repository Injection Successfull");
    }
}
