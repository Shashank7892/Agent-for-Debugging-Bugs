package com.example.demo.service;

import com.example.demo.dtohelpers.QueryResponseDTO;
import com.example.demo.entity.CodeChunk;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RagService {

    @Autowired
    private HybridSearchService hybridSearchService;

    @Autowired
    private GeminiService geminiService;

    @Autowired
    private ContextBuilderService contextBuilderService;

    @Autowired
    private RagPromptService ragPromptService;

    public QueryResponseDTO ask(String query){
        List<CodeChunk> chunks=hybridSearchService.search(query);

        // 2. rag prmopt
        String context= contextBuilderService.buildContext(chunks);
        String prompt= ragPromptService.buildPrompt(query,context);

        //3 send ragprompt to gemini
        System.out.println(geminiService.generateAnswer(prompt));

        return new QueryResponseDTO(query, geminiService.generateAnswer(prompt));
    }
}
