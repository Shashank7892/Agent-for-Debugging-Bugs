package com.example.demo.service;

import com.example.demo.agents.CodeSearchTool;
import com.example.demo.dtohelpers.QueryResponseDTO;
import org.jspecify.annotations.Nullable;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AgentService {

    private ChatClient chatClient;

    @Autowired
    private ChatClient.Builder chatClientBuilder;

    @Autowired
    private CodeSearchTool codeSearchTool;

    public QueryResponseDTO ask(String query){

        chatClient=chatClientBuilder.build();

        String result= chatClient
                .prompt()
                .system("""
                You are an AI software debugging agent.

                You have access to a repository code search tool.

                When the user's question requires repository
                information, use the searchCode tool.

                Use the tool only when necessary.

                Do not repeatedly call the searchCode tool with
                the same or nearly identical query.

                After receiving useful code from the tool, analyze
                that code and provide the answer.

                Do not assume code that you have not inspected.

                If the available repository evidence is insufficient,
                clearly state what information is missing.
                """)
                .user(query)
                .tools(codeSearchTool)
                .call()
                .content();

        return new QueryResponseDTO(query,result);
    }
}
