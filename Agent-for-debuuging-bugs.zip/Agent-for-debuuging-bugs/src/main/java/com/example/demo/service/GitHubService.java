package com.example.demo.service;

import com.example.demo.clients.GitHubClient;
import com.example.demo.config.GitHubConfig;
import com.example.demo.dtohelpers.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@Service
public class GitHubService {

    @Autowired
    private GitHubClient gitHubClient;

    @Autowired
    private GitHubConfig gitHubConfig;

    public TargetApplicationResponse getTargetApplication(){
        GitHubRepositoryResponse repository=gitHubClient.getTargetRepository();

        String branch=gitHubConfig.getBranch();

        return new TargetApplicationResponse(repository.getName(),repository.getFull_name(),branch,"Connected",null);
    }

    public List<String> getAllFiles(){

        GitHubTreeResponse response=gitHubClient.getRespositoryTree();

        return response.getTree()
                .stream()
                .filter(item->"blob".equals(item.getType()))
                .map(GitHubTreeResponse.TreeItem::getPath)
                .toList();
    }

    public GitHubContentResponse[] getContents(){

        return gitHubClient.getRootContents();
    }

    public FileData readContent(String path) {

        GitHubPathData data=gitHubClient.getContentData(path);
        String base64Content = data.getContent()
                .replaceAll("\\s", "");
        String content=decodeBase64(base64Content);
        return new FileData(data.getPath(),content);
    }

    private String decodeBase64(String content){

        return new String(Base64.getDecoder().decode(content),StandardCharsets.UTF_8);
    }
}
