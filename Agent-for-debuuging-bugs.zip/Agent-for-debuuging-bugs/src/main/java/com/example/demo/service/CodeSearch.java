package com.example.demo.service;

import com.example.demo.entity.CodeDocument;
import com.example.demo.repository.CodeDocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CodeSearch {

    @Autowired
    private CodeDocumentRepository codeDocumentRepository;


    public List<CodeDocument> search(String query){

        List<CodeDocument> result=codeDocumentRepository.findByPathContainingIgnoreCaseOrContentContainingIgnoreCase(query,query);

        return result;
    }
}
