package com.example.demo.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;

@Service
public class JwtService {

    private final PrivateKey privateKey;

    private final PublicKey publicKey;

    public JwtService(@Value("${jwt.private.key}") String privatekeystr,
                      @Value("${jwt.public.key}") String publickeystr) {
        try {
            this.privateKey = loadprivateKey(privatekeystr);
            this.publicKey = loadpublickey(publickeystr);
        } catch (Exception ex) {
            throw new RuntimeException("Error in Loading RSA",ex);
        }
    }

    public String generateToken(String email,String name) {
        return Jwts.builder()
                .subject(email)
                .claim("username",name)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis()+1000*60*60))
                .signWith(privateKey,Jwts.SIG.RS256)
                .compact();
    }

    public Claims getClaims(String token){
        return Jwts.parser()
                .verifyWith(publicKey)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String extractUseremail(String token) {
        return getClaims(token).getSubject();
    }

    public boolean isValid(String token) {
        try{
            getClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private PrivateKey loadprivateKey(String privatekeystr) throws Exception{
        String cleanedkey=privatekeystr.replace("\\s+","");
        byte[] decoded= Base64.getDecoder().decode(cleanedkey);
        PKCS8EncodedKeySpec spec=new PKCS8EncodedKeySpec(decoded);
        return KeyFactory.getInstance("RSA").generatePrivate(spec);
    }

    private PublicKey loadpublickey(String publickeystr) throws Exception{
        String cleanedkey=publickeystr.replace("\\s+","");
        byte[] decoded=Base64.getDecoder().decode(cleanedkey);
        X509EncodedKeySpec spec=new X509EncodedKeySpec(decoded);
        return KeyFactory.getInstance("RSA").generatePublic(spec);
    }



}
