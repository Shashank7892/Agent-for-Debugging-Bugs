package com.example.demo.dtohelpers;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GitHubContentResponse {

    private String name;

    private String path;

    private String type;

    private String sha;

    private String html_url;

}
