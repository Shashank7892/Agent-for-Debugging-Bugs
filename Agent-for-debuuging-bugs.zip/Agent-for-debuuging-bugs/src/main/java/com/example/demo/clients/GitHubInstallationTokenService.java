package com.example.demo.clients;

import com.example.demo.config.GitHubConfig;
import com.example.demo.dtohelpers.InstallationResponse;
import com.example.demo.dtohelpers.InstallationTokenResponse;
import com.example.demo.jwt.GitHubJwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class GitHubInstallationTokenService {


    private final WebClient webClient;

    @Autowired
    private GitHubJwtService gitHubJwtService;

    @Autowired
    private GitHubConfig config;

    public GitHubInstallationTokenService(){
        this.webClient= WebClient.builder()
                .baseUrl("https://api.github.com")
                .defaultHeader(HttpHeaders.ACCEPT,"application/vnd.github+json")
                .defaultHeader("X-GitHub-Api-Version","2022-11-28")
                .build();
    }

    public String getInstallationToken(){
        try{
            String appjwt=gitHubJwtService.generateGitHubAppJwt();

            Long installionId=getInstallationId(appjwt);

            InstallationTokenResponse response=webClient
                    .post()
                    .uri("app/installations/{id}/access_tokens",installionId)
                    .header(HttpHeaders.AUTHORIZATION,"Bearer "+appjwt)
                    .retrieve()
                    .bodyToMono(InstallationTokenResponse.class)
                    .block();
            if(response==null || response.getToken()==null){
                throw new RuntimeException("Failed to get github Installation token");
            }
            return response.getToken();
        } catch (Exception e) {
            throw new RuntimeException("Failed to Authenticate with Github app",e);
        }
    }

    private Long getInstallationId(String appjwt){
        InstallationResponse response= webClient.get()
                .uri("repos/{owner}/{repo}/installation",config.getOwner(),config.getRepository())
                .header(HttpHeaders.AUTHORIZATION,"Bearer "+appjwt)
                .retrieve()
                .bodyToMono(InstallationResponse.class)
                .block();
        if(response==null){
            throw new RuntimeException("GitHub app not installaed for this repository");
        }
        return response.getId();
    }
}
