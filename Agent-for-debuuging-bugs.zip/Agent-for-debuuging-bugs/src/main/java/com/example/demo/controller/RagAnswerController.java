package com.example.demo.controller;

import com.example.demo.dtohelpers.QueryRequestDTO;
import com.example.demo.dtohelpers.QueryResponseDTO;
import com.example.demo.service.RagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/rag")
public class RagAnswerController {

    @Autowired
    private RagService ragService;


    @PostMapping("/askquery")
    private ResponseEntity<QueryResponseDTO> askResult(@RequestBody QueryRequestDTO query){
        QueryResponseDTO answer=ragService.ask(query.getQuery());

        return ResponseEntity.status(HttpStatus.OK).body(answer);
    }
}
