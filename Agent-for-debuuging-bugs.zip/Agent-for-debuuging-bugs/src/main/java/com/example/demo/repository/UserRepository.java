package com.example.demo.repository;

import com.example.demo.entity.UserDetailss;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<UserDetailss,Long> {
    Optional<UserDetailss> findByEmail(String email);

}
